-- Sanchez Hernandez Alejandro Ernesto 
-- Soto Moreno Gerardo Ivan 
-- Guatemala Trujillo Leonardo
-- Rodriguez Trejo Diego 

-- 1.1 Crear un usuario que pueda realizar lecturas en todas las tablas, con una limitación de 15 consultas por hora.
create user 'lector'@'localhost' identified by 'lector' with max_queries_per_hour 15;
grant select on credito.* to 'lector'@'localhost';

-- 1.2 Un usuario con permisos de lectura y escritura en todas las tablas, limitado a 2 conexiones concurrentes y prohibido realizar operaciones DDL.
create user 'lecyesc'@'localhost' identified by 'lecyesc' with max_user_connections 2;
grant select, insert, update, delete on credito.* to  'lecyesc'@'localhost';
revoke create, drop, alter on credito.* from 'lecyesc'@'localhost';

show grants for 'lector'@'localhost';
show grants for 'lecyesc'@'localhost';

-- 2.1 Implementar un procedimiento almacenado que calcule el consumo diario por tienda y tipo de movimiento, agregando los resultados a una tabla concentrado_consumo, con campos adicionales para tipo de pago y descuento aplicado.
USE credito;

CREATE TABLE concentrado_consumo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    tiendano INT NOT NULL,
    movimiento VARCHAR(50) NOT NULL,
    suma DECIMAL(10, 2) NOT NULL,
    tipo_pago VARCHAR(50) NOT NULL DEFAULT 'Tarjeta', 
    descuento DECIMAL(5, 2) NOT NULL DEFAULT 0.00 
);

DELIMITER //

CREATE PROCEDURE PA2(IN buscar INT)
BEGIN
    DECLARE registro_B INT DEFAULT 0;
    SELECT COUNT(*)
    INTO registro_B 
    FROM empleado
    WHERE empno = buscar;
    IF registro_B > 0 THEN
        INSERT INTO concentrado_consumo (fecha, tiendano, movimiento, suma, tipo_pago, descuento)
        SELECT 
            fecha, 
            tiendano, 
            movimiento, 
            SUM(importe) AS suma, 
            'Tarjeta' AS tipo_pago, 
            0.00 AS descuento 
        FROM 
            consumo 
        GROUP BY 
            fecha, 
            tiendano, 
            movimiento
        ORDER BY 
            tiendano, fecha;
    ELSE
        SELECT 'Numero de empleado NO existe' AS RESULTADO;
    END IF;
END //

DELIMITER ;

CALL PA2(12001);
select * from concentrado_consumo;

-- 2.2 Crear un procedimiento almacenado que, dado un número de empleado, devuelva el consumo total, la cantidad de transacciones y el promedio de consumo por tienda.
DELIMITER //

CREATE PROCEDURE PA22(IN buscar INT)
BEGIN
    DECLARE registro_B INT DEFAULT 0;
    SELECT COUNT(*)
    INTO registro_B 
    FROM cuenta
    WHERE empno = buscar;
    IF registro_B > 0 THEN
        SELECT 
            tiendano,
            SUM(importe) AS consumo_total,
            COUNT(*) AS cantidad_transacciones,
            AVG(importe) AS promedio_consumo
        FROM 
            consumo
        WHERE 
            cuentano IN (SELECT cuentano FROM cuenta WHERE empno = buscar)
        GROUP BY 
            tiendano;
    ELSE
        SELECT 'Numero de empleado NO existe' AS RESULTADO;
    END IF;
END //

DELIMITER ;

CALL PA22(12001);

-- 3.1 Desarrollar un trigger que registre en una bitácora los cambios y eliminaciones en las tablas de consumo, cuenta, empleado y tienda, incluyendo la fecha y usuario que efectuó el cambio.
CREATE TABLE bitacora (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tabla VARCHAR(50),
    accion VARCHAR(10),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50),
    detalles VARCHAR(255)
);

-- Triggers para empleado

-- Insert en empleado
DELIMITER //
CREATE TRIGGER bitacora_I_EM
AFTER INSERT ON empleado
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('empleado', 'INSERT', CURRENT_USER(), CONCAT('Numero ', NEW.empno,'.'));
END //

-- Delete en empleado
DELIMITER //
CREATE TRIGGER bitacora_D_EM
AFTER DELETE ON empleado
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('empleado', 'DELETE', CURRENT_USER(), CONCAT('Numero ', OLD.empno,'.'));
END //

-- Update en empleado
DELIMITER //
CREATE TRIGGER bitacora_U_EM
AFTER UPDATE ON empleado
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('empleado', 'UPDATE', CURRENT_USER(), CONCAT('Numero ', NEW.empno,'.'));
END //

-- Triggers para Cuenta

-- Insert en Cuenta
DELIMITER //
CREATE TRIGGER bitacora_I_CU
AFTER INSERT ON cuenta
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('cuenta', 'INSERT', CURRENT_USER(), CONCAT('Cuenta num ', NEW.cuentano,'.'));
END //

-- Delete en cuenta
DELIMITER //
CREATE TRIGGER bitacora_D_CU
AFTER DELETE ON cuenta
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('cuenta', 'DELETE', CURRENT_USER(), CONCAT('Cuenta num ', OLD.cuentano,'.'));
END //

-- Update en cuenta
DELIMITER //
CREATE TRIGGER bitacora_U_CU
AFTER UPDATE ON cuenta
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('cuenta', 'UPDATE', CURRENT_USER(), CONCAT('Cuenta num ', NEW.cuentano,'.'));
END //

-- Triggers para consumo

-- Insert en Consumo
DELIMITER //
CREATE TRIGGER bitacora_I_CO
AFTER INSERT ON consumo
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('consumo', 'INSERT', CURRENT_USER(), CONCAT('Cuenta num ', NEW.cuentano,' importe ', NEW.importe,'.'));
END //

-- Delete en Consumo
DELIMITER //
CREATE TRIGGER bitacora_D_CO
AFTER DELETE ON consumo
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('consumo', 'DELETE', CURRENT_USER(), CONCAT('Cuenta num ', OLD.cuentano,' importe ', OLD.importe,'.'));
END //

-- Update en Consumo
DELIMITER //
CREATE TRIGGER bitacora_U_CO
AFTER UPDATE ON consumo
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('consumo', 'UPDATE', CURRENT_USER(), CONCAT('Cuenta num ', NEW.cuentano,' importe ', NEW.importe,'.'));
END //

-- Triggers para tienda

-- Insert en tienda
DELIMITER //
CREATE TRIGGER bitacora_I_TI
AFTER INSERT ON tienda
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('tienda', 'INSERT', CURRENT_USER(), CONCAT('Tienda no ', NEW.tiendano,'.'));
END //

-- Delete en tienda
DELIMITER //
CREATE TRIGGER bitacora_D_TI
AFTER DELETE ON tienda
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('tienda', 'DELETE', CURRENT_USER(), CONCAT('Tienda no ', OLD.tiendano,'.'));
END //

-- Update en tienda
DELIMITER //
CREATE TRIGGER bitacora_U_TI
AFTER UPDATE ON tienda
FOR EACH ROW
BEGIN 
    INSERT INTO bitacora (tabla, accion, usuario, detalles)
    VALUES ('tienda', 'UPDATE', CURRENT_USER(), CONCAT('Tienda no ', NEW.tiendano,'.'));
END //

-- 3.2 Establecer un trigger que impida la inserción de consumos con importes negativos o nulos.
DELIMITER //

CREATE TRIGGER TR2
    BEFORE INSERT ON consumo
    FOR EACH ROW
    BEGIN
        IF NEW.importe <= 0 THEN 
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El importe no puede ser igual a cero o nulo';
        END IF;
    END //

DELIMITER ;

-- 4 Automatización de Respaldo de la Base de Datos
/*
REM Este  el archivo bat perteneciente al proyecto

@echo off
SET BASE_DATOS=%1
:: SET ARCHIVO_CONFIGURACION="C:\Users\Alejandro\Documents\parametros.cfg"
SET ARCHIVO_CONFIGURACION="C:\Users\Alejandro\Documents\8vo\bD\bd.txt"
SET RUTA_RESPALDO="C:\Users\Alejandro\Documents\RESPALDO"

:loop

FOR /F "tokens=2 delims==" %%I IN ('wmic OS Get localdatetime /value') DO SET DATETIME=%%I
SET DATE_TIME=%DATETIME:~0,4%%DATETIME:~4,2%%DATETIME:~6,2%%DATETIME:~8,2%%DATETIME:~10,2%%DATETIME:~12,2%

SET ARCHIVO_RESPALDO=%DATE_TIME%_%BASE_DATOS%.sql
SET RUTA_ARCHIVO_RESPALDO="%RUTA_RESPALDO%/%ARCHIVO_RESPALDO%"

mysqldump --defaults-file="%ARCHIVO_CONFIGURACION%" %BASE_DATOS% > "%RUTA_ARCHIVO_RESPALDO%"
echo Respaldo completo!

REM Esperar dos minutos (120 segundos)
REM timeout /t 120

REM para esperar una semana
timeout /t 604800

GOTO loop
*/

-- 5.1 Desarrollar una vista que muestre el detalle completo del concentrado de ventas, incluyendo datos de promociones aplicadas.
select * from consumo;
create view vista_5_1 as 
select cuentano, concat_ws('',fecha,"  ", tiendano,"  ", movimiento,"  ",importe,"  ") as detalles_venta from consumo;
select * from vista_5_1;


-- 5.2 Crear una vista que muestre el concentrado de ventas filtrado por tipo de tienda y rango de fechas.
CREATE OR REPLACE VIEW vista_5_2 AS
SELECT c.fecha, c.tiendano, t.tipo AS tipo_de_tienda, SUM(c.importe) AS total_ventas
FROM consumo AS c
INNER JOIN tienda AS t ON c.tiendano = t.tiendano
WHERE t.tipo = 'VIPS'
  AND c.fecha BETWEEN '2021-01-03' AND '2021-02-10'
GROUP BY c.fecha, c.tiendano, t.tipo;
SELECT * FROM vista_5_2;

-- 6 Configurar un usuario que únicamente tenga acceso a las vistas desarrolladas en los puntos 5.1 y 5.2. 
CREATE USER 'UsuarioChido'@'localhost' IDENTIFIED BY '1234';
GRANT SELECT ON credito.vista_5_1 TO  'UsuarioChido'@'localhost';
GRANT SELECT ON credito.vista_5_2 TO  'UsuarioChido'@'localhost';

